// 
// Decompiled by Procyon v0.5.30
// 

package org.takeback.chat.store;

import java.io.Serializable;

public interface Item extends Serializable
{
}
