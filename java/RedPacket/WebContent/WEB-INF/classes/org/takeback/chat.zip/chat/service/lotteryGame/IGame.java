// 
// Decompiled by Procyon v0.5.30
// 

package org.takeback.chat.service.lotteryGame;

public interface IGame
{
    How how(final String p0);
}
