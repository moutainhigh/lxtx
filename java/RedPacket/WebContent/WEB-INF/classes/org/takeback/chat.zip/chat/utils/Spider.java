// 
// Decompiled by Procyon v0.5.30
// 

package org.takeback.chat.utils;

import java.io.IOException;

public class Spider
{
    public static void main(final String[] args) throws IOException {
    }
}
