// 
// Decompiled by Procyon v0.5.30
// 

package org.takeback.chat.utils;

public class InfoUtils
{
}
