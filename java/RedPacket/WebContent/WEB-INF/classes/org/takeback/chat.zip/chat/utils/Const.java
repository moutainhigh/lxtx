// 
// Decompiled by Procyon v0.5.30
// 

package org.takeback.chat.utils;

public class Const
{
    public static final String RED_GAME = "2";
    public static final String RED_NORMAL = "1";
    public static final String ROOM_PLAYING = "1";
    public static final String ROOM_STOP = "0";
    public static final String CONF_LOOSER = "conf_looser";
    public static final String CONF_TITLE = "conf_title";
    public static final String CONF_COUNT = "conf_size";
    public static final String CONF_TIP = "conf_tip";
    public static final String CONF_BONUS = "conf_bonus";
    public static final String CONF_EXPIRED = "conf_expired";
    public static final String CONF_MAX_SIZE = "conf_max_size";
    public static final String CONF_MIN_SIZE = "conf_min_size";
    public static final String CONF_MAX_MONEY = "conf_max_money";
    public static final String CONF_MIN_MONEY = "conf_min_money";
    public static final String CONF_MONEY = "conf_money";
    public static final String CONF_MONEY_START = "conf_money_start";
    public static final String CONF_MONEY_GAME = "conf_money_game";
    public static final String CONF_N10 = "conf_n10";
    public static final String CONF_N13 = "conf_n13";
    public static final String BONUS_X = "b_";
    public static final String PROP_RAID = "raid";
}
