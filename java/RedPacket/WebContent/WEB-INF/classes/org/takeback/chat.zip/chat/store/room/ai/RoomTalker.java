// 
// Decompiled by Procyon v0.5.30
// 

package org.takeback.chat.store.room.ai;

public class RoomTalker
{
}
