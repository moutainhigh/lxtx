// 
// Decompiled by Procyon v0.5.30
// 

package org.takeback.chat.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.takeback.chat.entity.GcRoom;
import org.takeback.chat.entity.GcRoomProperty;
import org.takeback.chat.store.room.RoomStore;
import org.takeback.service.BaseService;

import com.google.common.collect.ImmutableMap;

@Service
public class RoomService extends BaseService {
	@Autowired
	RoomStore roomStore;
	private static int ONCE_FETCH_COUNT;

	@Transactional(readOnly = true)
	public List<GcRoom> getRooms(final int pageNo, final Map<String, Object> params) {
		return this.dao.find(GcRoom.class, params, RoomService.ONCE_FETCH_COUNT, pageNo, "hot desc,createdate desc");
	}

	@Transactional(readOnly = true)
	public List<GcRoom> getActivedRooms() {
		return this.dao.findByHql("from GcRoom a where a.status != '9' order by a.hot desc,a.createdate desc", null);
	}

	@Transactional(readOnly = true)
	public Map<String, Object> getRoomProperties(final String roomId) {
		final Map<String, Object> param = new HashMap<String, Object>();
		param.put("roomId", roomId);
		final List<GcRoomProperty> list = this.dao
				.findByHql("from GcRoomProperty a where roomId=:roomId order by id asc ", param);
		final Map<String, Object> res = new HashMap<String, Object>();
		for (final GcRoomProperty prop : list) {
			res.put(prop.getConfigKey(), prop.getConfigValue());
		}
		return res;
	}

	@Transactional(readOnly = true)
	public int getUserRoomCount(final Integer userId) {
		return (int) this.dao.count(GcRoom.class, ImmutableMap.of("owner", userId));
	}

	@Transactional(readOnly = true)
	public List<GcRoom> getUserRooms(final Integer userId, final int pageSize, final int pageNo) {
		return this.dao.findByHqlPaging("from GcRoom where owner=:owner", ImmutableMap.of("owner", userId), pageSize,
				pageNo);
	}

	@Transactional
	public void initRoomStatus() {
		this.dao.executeUpdate("update GcRoom set status ='0' ", new HashMap<String, Object>());
		final List<GcRoom> list = this.dao.findByHql("from GcRoom");
		for (final GcRoom rm : list) {
			this.roomStore.reload(rm.getId());
		}
	}

	@Transactional(readOnly = true)
	public List<Map<String, String>> getRoomProps(final String roomId) {
		final List<GcRoomProperty> list = this.dao.findByHql("from GcRoomProperty where roomId=:roomId",
				ImmutableMap.of("roomId", roomId));
		if (list == null || list.isEmpty()) {
			return new ArrayList<Map<String, String>>();
		}
		final List<Map<String, String>> props = new ArrayList<Map<String, String>>(list.size());
		for (final GcRoomProperty gcRoomProperty : list) {
			final String alias = StringUtils.isEmpty(gcRoomProperty.getAlias()) ? gcRoomProperty.getConfigKey()
					: gcRoomProperty.getAlias();
			final Map<String, String> map = ImmutableMap.of("key", gcRoomProperty.getConfigKey(), "value",
					gcRoomProperty.getConfigValue(), "alias", alias);
			props.add(map);
		}
		return props;
	}

	static {
		RoomService.ONCE_FETCH_COUNT = 5;
	}
}
