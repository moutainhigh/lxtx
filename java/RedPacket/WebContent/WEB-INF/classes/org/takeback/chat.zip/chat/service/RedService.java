// 
// Decompiled by Procyon v0.5.30
// 

package org.takeback.chat.service;

import org.springframework.stereotype.Service;
import org.takeback.service.BaseService;

@Service
public class RedService extends BaseService
{
}
