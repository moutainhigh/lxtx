// 
// Decompiled by Procyon v0.5.30
// 

package org.takeback.chat.store.user;

import org.takeback.chat.store.Store;

public interface UserStore extends Store<User>
{
    long size();
}
