// 
// Decompiled by Procyon v0.5.30
// 

package org.takeback.chat.store.lottery;

import org.takeback.chat.store.Item;
import org.takeback.chat.lottery.Lottery;
import java.io.Serializable;

public class DefaultLotteryStore implements LotteryStore
{
    @Override
    public Lottery get(final Serializable id) {
        return null;
    }
    
    @Override
    public void reload(final Serializable id) {
    }
    
    @Override
    public void init() {
    }
}
