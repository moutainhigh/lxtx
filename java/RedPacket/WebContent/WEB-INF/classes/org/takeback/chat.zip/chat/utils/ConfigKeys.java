// 
// Decompiled by Procyon v0.5.30
// 

package org.takeback.chat.utils;

public class ConfigKeys
{
    public static final String APP_NAME = "appName";
    public static final String COIN_UNIT = "coinUnit";
}
