// 
// Decompiled by Procyon v0.5.30
// 

package org.takeback.chat.store.lottery;

import org.takeback.chat.lottery.Lottery;
import org.takeback.chat.store.Store;

public interface LotteryStore extends Store<Lottery>
{
}
